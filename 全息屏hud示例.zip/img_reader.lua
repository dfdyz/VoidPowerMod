img = {}

img.____read_int = function(str)
    local a,b,c,d = string.byte(str, 1, 4)
    return a * 0x1000000 + b * 0x10000 + c * 0x100 + d
end

img.read = function(path)
    local f = io.open(path, "rb")
    local IM = {}

    IM.width = img.____read_int(f:read(4))
    IM.height = img.____read_int(f:read(4))

    IM.pixels = {}

    local bytes = nil
    local i = 0
    while true do
        bytes = f:read(4)
        if bytes ~= nil then
            IM.pixels[i] = img.____read_int(bytes)
            i = i+1
        else
            break
        end
    end
    -- todo
    f:close()
    return IM
end

return img