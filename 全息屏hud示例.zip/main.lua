Input = dofile("input.lua")
Hub = dofile("hub.lua")
Vector = dofile("vector.lua")
HUD = dofile("fly_hud.lua"):New()

-- peripheral init
function FindPeripheral(p)
    return peripheral.find(p) or Hub.wrap(Hub.getPeripherals(p))[1]
end

EC = FindPeripheral("EngineController")
Hologram = FindPeripheral("hologram")
InputChannel = nil

HUD:BindScreen(Hologram)

-- data define
ShipPoseCache = {
    up = Vec.AxisY(),
    front = Vec.Negative(Vec.AxisZ()),
    right = Vec.AxisX()
}

yaw_off = 0

-- method define
function ButtonHandler(b)

end

function PhysTick(PhysData)
    InputChannel:Update()

    -- read control input
    local c_yaw = -InputChannel:GetAxis(1);
    local c_fwd = -InputChannel:GetAxis(2);
    local c_roll = -InputChannel:GetAxis(3);
    local c_pitch = -InputChannel:GetAxis(4);
    local c_spd_up = InputChannel:GetButton(1);

    -- setup phys data for this phys-frame
    local inerita = PhysData.getInertia()
    local pose = PhysData.getPoseVel()
    local ecPose = PhysData.getControllerFacesVec()

    local velocity = pose.velocity
    local velocity_len = Vec.Length(velocity)
    local _omega = Vec.Negative(pose.omega)

    local tensor = inerita.momentOfInertiaTensor[1][1]

    local up = ecPose.up
    local front = ecPose.front
    local right = Vec.Normalize(Vec.Cross(front, up))
    local tmp = {}

    HUD.PoseData.yaw = pose.yaw / math.pi * 180

    -- config
    local rot_damping = 15
    local rot_acc = 40

    local move_acc = 100
    if c_spd_up then
        move_acc = move_acc * 2
    end
    local brake_force = -inerita.mass * 5

    -- hover
    EC.applyInvariantForce(0, 10 * inerita.mass, 0)

    -- air brake
    --   move damping
    tmp = Vec.MulNum(velocity, brake_force)
    EC.applyInvariantForce(tmp.x, tmp.y, tmp.z)
    --   rot damping
    local _torque = Vec.MulNum(_omega, rot_damping * tensor)
    EC.applyInvariantTorque(_torque.x, _torque.y, _torque.z)

    -- fwd
    tmp = Vec.MulNum(front, c_fwd * inerita.mass * move_acc)
    EC.applyInvariantForce(tmp.x, tmp.y, tmp.z)

    -- rot ctrl
    --   roll ctrl
    tmp = Vec.MulNum(front, -c_roll * tensor * rot_acc)
    EC.applyInvariantTorque(tmp.x, tmp.y, tmp.z)
    --   yaw ctrl
    tmp = Vec.MulNum(up, c_yaw * tensor * rot_acc)
    EC.applyInvariantTorque(tmp.x, tmp.y, tmp.z)
    --   pitch ctrl
    tmp = Vec.MulNum(right, -c_pitch * tensor * rot_acc)
    EC.applyInvariantTorque(tmp.x, tmp.y, tmp.z)
end


function InitController()
    if InputChannel ~= nil then
        InputChannel.Close()
    end
    InputChannel = Input:NewChannel()
    Joy = peripheral.find("tweaked_controller") or Hub.wrap(Hub.getPeripherals("tweaked_controller"))[1]
    InputChannel:BindController(Joy)
    InputChannel:BindButtonCallback("Pressed", ButtonHandler)
end

function Main()
    InitController()


    local face = EC.getFaceRaw()

    if face.x > 0.5 then
        face = -90
    elseif face.x < -0.5 then
        face = 90
    elseif face.z < -0.5 then
        face = 180
    elseif face.z > 0.5 then
        face = 0
    end

    yaw_off = face

    EC.setIdle(false)
    local timer = os.startTimer(0.05)
    while true do
        local e = { os.pullEvent() }
        if e[1] == "phys_tick" then
            PhysTick(e[2])
        elseif e[1] == "timer" then
            if e[2] == timer then
                HUD:Draw()
                timer = os.startTimer(0.05)
            end
        end
    end
end

Main()