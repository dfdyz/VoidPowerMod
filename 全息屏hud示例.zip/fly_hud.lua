HUD = {}
Img = dofile("img_reader.lua")

function HUD:___init()
    HUD.___screen = nil
    HUD.PoseData = {
        yaw = 0,
        pitch = 0,
        roll = 0
    }
    HUD.___render_data = {
        texture_buffer = -1,
        texture_size = {
            512 , 64
        }
    }
end

function HUD:BindScreen(s)
    self.___screen = s
    if s ~= nil then
        s.SetRotation(0, 0, 0)
        s.SetTranslation(0, 1, 0)
        s.SetScale(0.125, 0.125)

        s.SetCurrentFrameBuffer(-1)
        s.Resize(256,128)
        s.SetClearColor(0x80FF8020)
        s.Clear()

        s.FreeAllFrameBuffer()
        -- load hud texture
        local img = Img.read("hud_north.bin")

        self.___render_data.texture_buffer = s.CreateFrameBuffer(img.width, img.height)
        s.SetCurrentFrameBuffer(self.___render_data.texture_buffer)
        s.Clear()
        s.Blit(0,0,img.width, img.height,img.pixels)
        s.SetCurrentFrameBuffer(-1)
    end
end

function HUD:___draw_rect(x, y, w, h, u0, v0, u1, v1, tex)
    self.___screen.DrawTriangleWithTexture(
            {x,   y,     u0, v0, 0xFFFFFFFF},
            {x,   y+h,   u0, v1, 0xFFFFFFFF},
            {x+w, y,     u1, v0, 0xFFFFFFFF},
            tex,
            2
    )
    self.___screen.DrawTriangleWithTexture(
            {x+w, y,     u1, v0, 0xFFFFFFFF},
            {x,   y+h,   u0, v1, 0xFFFFFFFF},
            {x+w, y+h,   u1, v1, 0xFFFFFFFF},
            tex,
            2
    )
end

function HUD:___draw_north_bar()
    local a = (self.PoseData.yaw + 360) % 360
    local px = 1 / 1024

    a = a / 360 * 0.5
    self.___screen.Fill(64, 20 ,128 ,40, 0x80FF8020)
    self:___draw_rect(64, 20, 128, 40,
            a + px, 1,  a + 0.25 + px * 2, 1 - (40 / 64), self.___render_data.texture_buffer)
end

function HUD:Draw()
    pcall(self.___draw, self)
end

function HUD:___draw()
    self:___draw_north_bar()
    self.___screen:Flush()
end

function HUD:New()
    local obj = {}
    setmetatable(obj,self)
    self.__index = self
    obj:___init()
    return obj
end

return HUD